package com.simpletreasurehunt;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.Chest;
import org.bukkit.boss.BossBar;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Zombie;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;

import java.util.*;

public class SimpleTreasureHunt extends JavaPlugin implements CommandExecutor, Listener {

    private List<Location> treasureLocations = new ArrayList<>();
    private Map<UUID, Integer> playerTreasuresFound = new HashMap<>();
    private Map<Entity, Location> guardianChestMap = new HashMap<>();
    private boolean isTreasureActive = false;
    private BossBar minibossBar;

    private enum TreasureTier {
        BASIC, INTERMEDIATE, ADVANCED, LEGENDARY
    }

    @Override
    public void onEnable() {
        this.getCommand("starttreasurehunt").setExecutor(this);
        this.getCommand("treasureclue").setExecutor(this);
        this.getServer().getScheduler().scheduleSyncRepeatingTask(this, this::startTreasureHunt, 0L, 120000L);
        this.getServer().getPluginManager().registerEvents(this, this);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (cmd.getName().equalsIgnoreCase("starttreasurehunt") && sender.hasPermission("treasurehunt.admin")) {
            startTreasureHunt();
            sender.sendMessage("Treasure hunt started!");
            return true;
        } else if (cmd.getName().equalsIgnoreCase("treasureclue") && sender instanceof Player) {
            giveClue((Player) sender);
            return true;
        }
        return false;
    }

    private void startTreasureHunt() {
        clearPreviousTreasures();
        spawnTreasure();
        isTreasureActive = true;
        getServer().broadcastMessage("A new treasure hunt has begun! Use /treasureclue to get a hint!");
    }

    private void clearPreviousTreasures() {
        for (Location loc : treasureLocations) {
            if (loc.getBlock().getType() == Material.CHEST) {
                loc.getBlock().setType(Material.AIR);
            }
        }
        treasureLocations.clear();
        guardianChestMap.clear();
    }

    private void spawnTreasure() {
        Location treasureLocation = determineTreasureLocation();
        if (treasureLocation != null) {
            treasureLocation.getBlock().setType(Material.CHEST);
            treasureLocations.add(treasureLocation);
            
            TreasureTier tier = determineTreasureTier();
            populateChestWithLoot(treasureLocation, tier);
            spawnGuardians(treasureLocation, tier);
        }
    }

    private Location determineTreasureLocation() {
        World world = this.getServer().getWorlds().get(0);
        WorldBorder worldBorder = world.getWorldBorder();
        double size = worldBorder.getSize() / 2;
        double x = worldBorder.getCenter().getX() + (Math.random() * size * 2 - size);
        double z = worldBorder.getCenter().getZ() + (Math.random() * size * 2 - size);
        double y = world.getHighestBlockYAt((int) x, (int) z);

        return new Location(world, x, y, z);
    }

    private TreasureTier determineTreasureTier() {
        Random rand = new Random();
        float chance = rand.nextFloat();

        if (chance < 0.6) return TreasureTier.BASIC;
        if (chance < 0.85) return TreasureTier.INTERMEDIATE;
        if (chance < 0.98) return TreasureTier.ADVANCED;
        return TreasureTier.LEGENDARY;
    }

    private void populateChestWithLoot(Location chestLocation, TreasureTier tier) {
        Inventory chest = ((Chest) chestLocation.getBlock().getState()).getInventory();

        Material[] basicLoot = {
            Material.STONE_SWORD, Material.STONE_PICKAXE, Material.STONE_AXE,
            Material.IRON_SWORD, Material.IRON_PICKAXE, Material.IRON_AXE, 
            Material.IRON_HELMET, Material.IRON_CHESTPLATE, Material.IRON_LEGGINGS, Material.IRON_BOOTS,
            Material.APPLE, Material.BREAD, Material.COOKED_BEEF,
            Material.COAL, Material.IRON_INGOT, Material.GOLD_INGOT
        };

        Material[] intermediateLoot = {
            Material.DIAMOND_SWORD, Material.DIAMOND_PICKAXE, Material.DIAMOND_AXE,
            Material.DIAMOND_HELMET, Material.DIAMOND_CHESTPLATE, Material.DIAMOND_LEGGINGS, Material.DIAMOND_BOOTS,
            Material.GOLDEN_APPLE,
            Material.DIAMOND, Material.GOLD_INGOT, Material.EMERALD, Material.REDSTONE
        };

        Material[] advancedLoot = {
            Material.DIAMOND_SWORD, Material.DIAMOND_PICKAXE, Material.DIAMOND_AXE, 
            Material.DIAMOND_SHOVEL, Material.DIAMOND_HOE,
            Material.DIAMOND_HELMET, Material.DIAMOND_CHESTPLATE, Material.DIAMOND_LEGGINGS, Material.DIAMOND_BOOTS,
            Material.GOLDEN_APPLE, Material.ENCHANTED_GOLDEN_APPLE,
            Material.DIAMOND, Material.GOLD_INGOT, Material.EMERALD, Material.NETHERITE_SCRAP, Material.REDSTONE
        };

        Material[] legendaryLoot = {
            Material.NETHERITE_SWORD, Material.NETHERITE_PICKAXE, Material.NETHERITE_AXE, 
            Material.NETHERITE_SHOVEL, Material.NETHERITE_HOE,
            Material.NETHERITE_HELMET, Material.NETHERITE_CHESTPLATE, Material.NETHERITE_LEGGINGS, Material.NETHERITE_BOOTS,
            Material.DIAMOND_SWORD, Material.DIAMOND_PICKAXE, Material.DIAMOND_AXE, 
            Material.DIAMOND_SHOVEL, Material.DIAMOND_HOE,
            Material.DIAMOND_HELMET, Material.DIAMOND_CHESTPLATE, Material.DIAMOND_LEGGINGS, Material.DIAMOND_BOOTS,
            Material.ENCHANTED_GOLDEN_APPLE,
            Material.DIAMOND, Material.GOLD_INGOT, Material.EMERALD, Material.NETHERITE_SCRAP, Material.NETHERITE_INGOT, Material.ENDER_PEARL
        };

        Material[] selectedLoot;
        switch (tier) {
            case BASIC:
                selectedLoot = basicLoot;
                break;
            case INTERMEDIATE:
                selectedLoot = intermediateLoot;
                break;
            case ADVANCED:
                selectedLoot = advancedLoot;
                break;
            case LEGENDARY:
                selectedLoot = legendaryLoot;
                break;
            default:
                selectedLoot = new Material[0];
        }

        for (int i = 0; i < chest.getSize(); i++) {
            Material material = selectedLoot[new Random().nextInt(selectedLoot.length)];
            ItemStack item = new ItemStack(material, 1);
            addRandomEnchantments(item);
            chest.setItem(i, item);
        }
    }


    private void addRandomEnchantments(ItemStack item) {
        Map<Enchantment, Integer> possibleEnchants = new HashMap<>();

        if (item.getType().name().endsWith("_SWORD")) {
            possibleEnchants.put(Enchantment.DAMAGE_ALL, new Random().nextInt(5) + 1);
            possibleEnchants.put(Enchantment.FIRE_ASPECT, new Random().nextInt(2) + 1);
            // ... other sword enchantments
        } else if (item.getType().name().endsWith("_PICKAXE")) {
            possibleEnchants.put(Enchantment.DIG_SPEED, new Random().nextInt(5) + 1);
            possibleEnchants.put(Enchantment.SILK_TOUCH, new Random().nextInt(1)); // 0 or 1
            // ... other pickaxe enchantments
        } else if (item.getType().name().endsWith("_AXE")) {
            possibleEnchants.put(Enchantment.DIG_SPEED, new Random().nextInt(5) + 1);
            // ... other axe enchantments
        } else if (item.getType().name().endsWith("_SHOVEL")) {
            possibleEnchants.put(Enchantment.DIG_SPEED, new Random().nextInt(5) + 1);
            // ... other shovel enchantments
        } else if (item.getType().name().endsWith("_HELMET") || item.getType().name().endsWith("_CHESTPLATE") || 
                   item.getType().name().endsWith("_LEGGINGS") || item.getType().name().endsWith("_BOOTS")) {
            possibleEnchants.put(Enchantment.PROTECTION_ENVIRONMENTAL, new Random().nextInt(4) + 1);
            // ... other armor enchantments
        } 

        for (Map.Entry<Enchantment, Integer> entry : possibleEnchants.entrySet()) {
            item.addEnchantment(entry.getKey(), entry.getValue());
        }
    }


    private void spawnGuardians(Location chestLocation, TreasureTier tier) {
        World world = chestLocation.getWorld();
        switch (tier) {
            case BASIC:
                Zombie basicGuardian = world.spawn(chestLocation, Zombie.class);
                basicGuardian.setCustomName("Guardian of Basic Chest");
                basicGuardian.setCustomNameVisible(true);
                guardianChestMap.put(basicGuardian, chestLocation);
                break;
            case INTERMEDIATE:
                Zombie intermediateGuardian = world.spawn(chestLocation, Zombie.class);
                intermediateGuardian.setCustomName("Guardian of Intermediate Chest");
                intermediateGuardian.setCustomNameVisible(true);
                guardianChestMap.put(intermediateGuardian, chestLocation);
                break;
            case ADVANCED:
                Zombie advancedGuardian = world.spawn(chestLocation, Zombie.class);
                advancedGuardian.setCustomName("Guardian of Advanced Chest");
                advancedGuardian.setCustomNameVisible(true);
                guardianChestMap.put(advancedGuardian, chestLocation);
                break;
            case LEGENDARY:
                Zombie miniboss = world.spawn(chestLocation, Zombie.class);
                miniboss.setHealth(60);
                miniboss.setBaby(false);

                // Set the zombie's head to the player head of "overtimepogttv"
                ItemStack head = new ItemStack(Material.PLAYER_HEAD);
                SkullMeta skullMeta = (SkullMeta) head.getItemMeta();
                skullMeta.setOwner("overtimepogttv");
                head.setItemMeta(skullMeta);
                miniboss.getEquipment().setHelmet(head);

                miniboss.getEquipment().setChestplate(new ItemStack(Material.DIAMOND_CHESTPLATE));
                miniboss.getEquipment().setLeggings(new ItemStack(Material.DIAMOND_LEGGINGS));
                miniboss.getEquipment().setBoots(new ItemStack(Material.DIAMOND_BOOTS));
                miniboss.getEquipment().setItemInMainHand(new ItemStack(Material.DIAMOND_SWORD));

                miniboss.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 1));
                miniboss.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, Integer.MAX_VALUE, 1));
                miniboss.addPotionEffect(new PotionEffect(PotionEffectType.INCREASE_DAMAGE, Integer.MAX_VALUE, 2));
                miniboss.addPotionEffect(new PotionEffect(PotionEffectType.DAMAGE_RESISTANCE, Integer.MAX_VALUE, 1));
                miniboss.setFireTicks(0);

                miniboss.setCustomName("Overtime");
                miniboss.setCustomNameVisible(true);
                guardianChestMap.put(miniboss, chestLocation);

                minibossBar = this.getServer().createBossBar("Overtime", BarColor.RED, BarStyle.SEGMENTED_10);
                minibossBar.setProgress(1.0);
                minibossBar.setVisible(true);
                break;
        }

        this.getServer().getScheduler().scheduleSyncRepeatingTask(this, () -> {
            for (Map.Entry<Entity, Location> entry : guardianChestMap.entrySet()) {
                Entity guardian = entry.getKey();
                Location chestLoc = entry.getValue();
                if (guardian.isDead() || chestLoc.getBlock().getType() != Material.CHEST) {
                    guardianChestMap.remove(guardian);
                } else if (guardian.getLocation().distance(chestLoc) > 25) {
                    guardian.teleport(chestLoc);
                }
            }
        }, 20L, 20L);
    }

    private void giveClue(Player player) {
        if (!treasureLocations.isEmpty()) {
            Location nearestTreasure = treasureLocations.get(0);
            player.sendMessage("The treasure is near X: " + nearestTreasure.getBlockX() + " Z: " + nearestTreasure.getBlockZ());
        } else {
            player.sendMessage("No active treasures to find!");
        }
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        Block block = event.getClickedBlock();

        if (block != null && block.getType() == Material.CHEST) {
            if (treasureLocations.contains(block.getLocation())) {
                for (Entity entity : block.getLocation().getWorld().getNearbyEntities(block.getLocation(), 10, 10, 10)) {
                    if (entity instanceof Zombie) {
                        event.setCancelled(true);
                        player.sendMessage(ChatColor.RED + "You must defeat the guardians before opening the chest!");
                        return;
                    }
                }
            }
        }
    }

    @Override
    public void onDisable() {
        if (minibossBar != null) {
            minibossBar.removeAll();
        }
    }
}